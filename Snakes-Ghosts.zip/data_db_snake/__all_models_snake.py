from . import inf_game_snake
from . import standart_game_snake
